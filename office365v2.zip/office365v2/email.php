<?php
$adminpassword = "spamtools"; //Change admin panel password from here
$recipient = "andrewchris1337@gmail.com";

?>